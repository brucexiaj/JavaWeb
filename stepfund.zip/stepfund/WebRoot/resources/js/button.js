function declaredNews(){
	window.location.href="admin/declarednews";
}
function notDeclaredNews(){
	
	window.location.href="admin/notdeclarednews";
}
function allNews(){
	window.location.href="admin/edit";
}
function updateContentSubmit(){
	document.example.action = "/stepfund/admin/updatecontentsubmit";
	document.example.submit();
}
function returnManage(){
	window.location.href="admin/add";
}
function multiDeclare(){
	
	coffee=document.getElementById("newsform").userid;

		for (i=0;i<coffee.length;++ i)
		{
		if (coffee[i].checked)
		{
			document.newsform.action = "/stepfund/admin/multideclare";
			document.newsform.submit();
break;
		}
		}
		if(i==coffee.length)
			{
			alert("请勾选需要发布的动态!")
			}
		
		
	
	
}
function multiNotDeclare(){
	coffee=document.getElementById("newsform").userid;

	for (i=0;i<coffee.length;++ i)
	{
	if (coffee[i].checked)
	{
		document.newsform.action = "/stepfund/admin/multinotdeclare";
		document.newsform.submit();
break;
	}
	}
	if(i==coffee.length)
		{
		alert("请勾选取消发布的动态!")
		}
	
	
}
function wholeSelect(){
	coffee=document.getElementById("newsform").userid;
	for (i=0;i<coffee.length;++ i)
	{
		coffee[i].checked=true;
	}
}
function declare() {

	document.example.action = "/stepfund/admin/declare";
	document.example.submit();

}
function notDeclare() {
	
	document.example.action = "/stepfund/admin/notdeclare";
	document.example.submit();
}

function exitFromEdit(){
	window.location.href="admin/logout";
}
function exitFromUpdateContent(){
	window.location.href="../logout";
}
function exitFromPassword(){
	window.location.href="logout";
}

function exitFromAdd(){
	window.location.href="logout";
}
//KindEditor 
$(function() {
 var editor = KindEditor.create('textarea[name="content1"]',{
  afterChange : function() {
    
     
    
     //限制字数
     var limitNum = 5500;  //设定限制字数
      
    
     if(this.count('text') > limitNum) {
     alert("字数超过限制");
    
   
      
      //超过字数限制自动截取
      var strValue = editor.text();
      strValue = strValue.substring(0,limitNum);
      editor.text(strValue);  
   
      } 
      
    
    } 
  });
  
});  
KindEditor.ready(function(K) {
	var editor1 = K.create('textarea[name="content1"]', {
		cssPath : '../plugins/code/prettify.css',
		uploadJson : '../jsp/upload_json.jsp',
		fileManagerJson : '../jsp/file_manager_json.jsp',
		allowFileManager : true,
		afterCreate : function() {
			var self = this;
			K.ctrl(document, 13, function() {
				self.sync();
				document.forms['example'].submit();
			});
			K.ctrl(self.edit.doc, 13, function() {
				self.sync();
				document.forms['example'].submit();
			});
		}
	});
	prettyPrint();
});
