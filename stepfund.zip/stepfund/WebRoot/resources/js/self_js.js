stepfund// JavaScript Document
$(function(){

	//nav
	$(".navBtn").click(function(){
		$(".navList").slideToggle();
	});	
	
	$(".navBtn1").click(function(){
		$(".navList1").slideToggle();
	});	
		
})