$(document).ready(function(){
		$('#s').focusin(function(){
			var val = $(this).val();
			if(val == '请输入搜索内容...'){
				$(this).val('');
			}
		});
		
		$('#s').focusout(function(){
			var val = $(this).val();
			if(val == ''){
				$(this).val('请输入搜索内容...');
			}
		});
		
		$('#weeknews_triger').click(function(){
			$('#weeknews').animate({
				height: '293'
			});
			$('#medianews').animate({
				height: '40'
			});
		});
		
		$('#medianews_triger').click(function(){
			$('#weeknews').animate({
				height: '40'
			});
			$('#medianews').animate({
				height: '293'
			});
		});
		
		$('.link2home').hover(function(){
			$(this).css('background-position','0 -30px');
			$('body').animate({backgroundPosition: '0 0'});
                        $('#header_top_nav a').hide();
                        $('#header_top_nav a.more').show();
			$('#header_top_nav').animate({height: 20});
		});
                
                $('.imp_news').hover(function(){
			$('body').animate({backgroundPosition: '0 0'});
                        $('#header_top_nav a').hide();
                        $('#header_top_nav a.inews').show();
			$('#header_top_nav').animate({height: 20});
		});
                
                 $('.camp_news').hover(function(){
			$('body').animate({backgroundPosition: '0 0'});
                        $('#header_top_nav a').hide();
                        $('#header_top_nav a.cnews').show();
			$('#header_top_nav').animate({height: 20});
		});
	
		$('#slides').slides({
			preload: true,
			preloadImage: 'images/ajax-loader.gif',
			effect: 'slide',
			play: 5000,
			pause: 2500,
			hoverPause: true,
			animationStart: function(current){
				$('.caption').animate({
					bottom:0,
					right: 40,
					opacity: 0
				},200);
			},
			animationComplete: function(current){
				$('.caption').animate({
					bottom:20,
					right: 40,
					opacity: 1
				},200);
			},
			slidesLoaded: function() {
				$('.caption').animate({
					bottom:20,
					right: 40,
					opacity: 1
				},200);
			}
		});
                
                 $('#wrapper').bind("mouseleave",function(){
                      $('#header_top_nav').animate({height: 0});
                     $('body').animate({backgroundPosition: '0 -20px'});
              });
	});
	