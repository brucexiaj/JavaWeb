package fund.service;

import java.util.List;











import javax.annotation.Resource;

import org.hibernate.Criteria;
import org.hibernate.criterion.Order;
import org.hibernate.criterion.Restrictions;
import org.springframework.stereotype.Service;




import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import fund.page.Pager;
import fund.dao.INewsDao;
import fund.model.News;


@Service("newsService")
public class NewsService implements INewsService {

	private INewsDao newsDao;
	
	
public INewsDao getNewsDao() {
	return newsDao;
}
@Resource
public void setNewsDao(INewsDao newsDao) {
	this.newsDao = newsDao;
}

	@Override
	public List<News> findAll()
	{
		return newsDao.findAll();
	}
	@Override
	public Pager<News> find() {
		return newsDao.find();
	}	
	@Override
	public Pager<News> findDeclared() 
	{
		return newsDao.findDeclared();
	}
	@Override
	public void add(News news)
	{
		newsDao.add(news);
	}
	@Override
	public News getById(int id)
	{
		return newsDao.getById(id);
	}
	@Override
	public void delete(News news)
	{
		newsDao.delete(news);
	}
	@Override
	public Pager<News> getByTime(String time)
	{
		return newsDao.getByTime(time);
	}
	@Override
	public Pager<News> getDeclaredNews(int state)
	{
		return newsDao.getDeclaredNews(state);
	}
	@Override
	public void changeState(int id)
	{
		newsDao.changeState(id);
	}
	@Override
	public void upadteContent(News oldone,News newone)
	{
		newsDao.upadteContent(oldone,newone);
	}

}
