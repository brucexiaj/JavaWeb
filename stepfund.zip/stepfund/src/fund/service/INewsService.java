package fund.service;

import java.util.List;








import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import fund.page.Pager;
import fund.model.News;




public interface INewsService {
	
	
		
		public List<News> findAll();
		public Pager<News> find();
		public Pager<News> findDeclared() ;
		public void add(News news);
public News getById(int id);
public void delete(News news);
public Pager<News> getByTime(String time);
public Pager<News> getDeclaredNews(int state);
public void changeState(int id);
public void upadteContent(News oldone,News newone);
}
