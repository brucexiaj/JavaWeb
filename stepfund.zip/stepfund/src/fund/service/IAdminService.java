package fund.service;

import java.util.List;











import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import fund.page.Pager;
import fund.model.Admin;
import fund.model.News;




public interface IAdminService {
	
	
		
public Admin getPass();
public void updatePassword(String newpassword);

}
