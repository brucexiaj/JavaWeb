package fund.service;

import java.util.List;














import javax.annotation.Resource;

import org.hibernate.Criteria;
import org.hibernate.criterion.Order;
import org.hibernate.criterion.Restrictions;
import org.springframework.stereotype.Service;




import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import fund.page.Pager;
import fund.dao.IAdminDao;
import fund.dao.INewsDao;
import fund.model.Admin;
import fund.model.News;


@Service("adminService")
public class AdminService implements IAdminService {

	private IAdminDao adminDao;

	public IAdminDao getAdminDao() {
		return adminDao;
	}
	@Resource
	public void setAdminDao(IAdminDao adminDao) {
		this.adminDao = adminDao;
	}
	@Override
	public Admin getPass()
	{
		return adminDao.getPass();
	}
	@Override
	public void updatePassword(String newpassword)
	{
		adminDao.updatePassword(newpassword);
	}
	

}
