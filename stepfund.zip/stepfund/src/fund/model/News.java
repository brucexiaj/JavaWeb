package fund.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Transient;

import org.hibernate.validator.constraints.NotEmpty;



@Entity
@Table(name="news")
public class News {
	private int id;
	private int state;
	private String title;
	
	private String content;
	
	private String time;
	private String picture;
	private String introduce;
	
	
	@Column(name="picture")
	public String getPicture() {
		return picture;
	}
	public void setPicture(String picture) {
		this.picture = picture;
	}
	@GeneratedValue
	@Id
	@Column(name="id")
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	@Column(name="title")
	public String getTitle() {
		return title;
	}
	public void setTitle(String title) {
		this.title = title;
	}
	@Column(name="state")
	public int getState() {
		return state;
	}
	public void setState(int state) {
		this.state = state;
	}
	@Column(name="content")
	public String getContent() {
		return content;
	}
	public void setContent(String content) {
		this.content = content;
	}
	@Column(name="introduce")
	public String getIntroduce() {
		return introduce;
	}
	
	public void setIntroduce(String introduce) {
		this.introduce = introduce;
	}
	@GeneratedValue
	@Column(name="time")
	public String getTime() {
		return time;
	}
	
	public void setTime(String time) {
		this.time = time;
	}
	//包含所有变量的构造函数
	public News(int id, int state, String title,  String time,String content,
			String picture, String introduce) {
		super();
		this.id = id;
		this.state = state;
		this.title = title;
		this.content = content;
		this.time = time;
		this.picture = picture;
		this.introduce = introduce;
	}
	//不包括id和time
	public News(int state, String title, String content, String picture,
			String introduce) {
		super();
		this.state = state;
		this.title = title;
		this.content = content;
		this.picture = picture;
		this.introduce = introduce;
	}
	//除了time
	public News(int id, int state, String title, String content,
			String picture, String introduce) {
		super();
		this.id = id;
		this.state = state;
		this.title = title;
		this.content = content;
		this.picture = picture;
		this.introduce = introduce;
	}
	public News() {
		super();
	}
	
}
