package fund.model;
/*
 * author:xiajun
 * time:20160701
 * function:用于进行数据库操作成功之后提醒的类
 */
public class Inform
{
	private String title;
	private String content;
	//包含所有变量的构造函数
	public Inform(String title, String content) {
		super();
		this.title = title;
		this.content = content;
	}
	//只包含title的构造函数
	public Inform(String title) {
		super();
		this.title = title;
	}
	
	public String getTitle() {
		return title;
	}
	
	public void setTitle(String title) {
		this.title = title;
	}
	public String getContent() {
		return content;
	}
	public void setContent(String content) {
		this.content = content;
	}
}
