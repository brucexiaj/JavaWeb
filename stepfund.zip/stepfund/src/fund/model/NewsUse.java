package fund.model;

public class NewsUse {
private int id;
private String state;
private String title;
private String time;
private String content;
public int getId() {
	return id;
}
public void setId(int id) {
	this.id = id;
}
public NewsUse(int id, String state, String title, String time, String content,
		String picture, String introduce, String change) {
	super();
	this.id = id;
	this.state = state;
	this.title = title;
	this.time = time;
	this.content = content;
	this.picture = picture;
	this.introduce = introduce;
	this.change = change;
}
public String getState() {
	return state;
}
public void setState(String state) {
	this.state = state;
}
public String getTitle() {
	return title;
}
public void setTitle(String title) {
	this.title = title;
}
public String getTime() {
	return time;
}
public void setTime(String time) {
	this.time = time;
}
public String getContent() {
	return content;
}
public void setContent(String content) {
	this.content = content;
}
public String getPicture() {
	return picture;
}
public void setPicture(String picture) {
	this.picture = picture;
}
public String getIntroduce() {
	return introduce;
}
public void setIntroduce(String introduce) {
	this.introduce = introduce;
}
public String getChange() {
	return change;
}
public void setChange(String change) {
	this.change = change;
}
private String picture;
private String introduce;
private String change;

}
