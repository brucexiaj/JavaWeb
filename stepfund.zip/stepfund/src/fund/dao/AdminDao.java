package fund.dao;



import javax.annotation.Resource;















import org.hibernate.Criteria;
import org.hibernate.Query;
import org.hibernate.SessionFactory;
import org.hibernate.criterion.Criterion;
import org.hibernate.criterion.Projections;
import org.springframework.orm.hibernate3.support.HibernateDaoSupport;
import org.springframework.stereotype.Repository;

















import fund.page.Pager;
import fund.page.SystemContext;
import fund.model.Admin;
import fund.model.News;



@Repository("adminDao")
public class AdminDao extends HibernateDaoSupport implements IAdminDao {
	  protected Class<News> entityClass;
	@Resource
	public void setSuperSessionFactory(SessionFactory sessionFactory) {
		this.setSessionFactory(sessionFactory);
	}
	
	
	
	
@Override
public Admin getPass()
{
	Admin a=(Admin)this.getSession().createQuery("from Admin where name=?")
			.setParameter(0, "step").uniqueResult();
	return a;
}
@Override
public void updatePassword(String newpassword)
{
	//这里用到是news而不是News
			this.getSession().createSQLQuery("update admin set password=? where name='step'")
			.setParameter(0, newpassword).executeUpdate();}


}
