package fund.dao;
import java.util.List;




import org.hibernate.Criteria;
import org.hibernate.criterion.Criterion;

import fund.model.News;
import fund.page.Pager;








public interface INewsDao {
	
	
	
	
	public List<News> findAll();
	public Pager<News> find();
	public Pager<News> findDeclared() ;
	public void add(News news);
	public void delete(News news);
	public News getById(int id);
	public Pager<News> getByTime(String time);
	public Pager<News> getDeclaredNews(int state);
	public void changeState(int id);
	public void upadteContent(News oldone,News newone);
	
	
	
}
