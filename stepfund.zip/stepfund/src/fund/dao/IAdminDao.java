package fund.dao;

import fund.model.Admin;
public interface IAdminDao{
	public Admin getPass();
	public void updatePassword(String newpassword);
}
















