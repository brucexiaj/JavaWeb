package fund.dao;

import java.text.SimpleDateFormat;


import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import javax.annotation.Resource;

import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.support.JdbcDaoSupport;














import org.hibernate.Criteria;
import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.criterion.Criterion;
import org.hibernate.criterion.Projections;
import org.springframework.orm.hibernate3.support.HibernateDaoSupport;
import org.springframework.stereotype.Repository;


















import fund.page.Pager;
import fund.page.SystemContext;
import fund.model.Admin;
import fund.model.News;



@Repository("newsDao")
public class NewsDao extends HibernateDaoSupport implements INewsDao {
	  protected Class<News> entityClass;
	@Resource
	public void setSuperSessionFactory(SessionFactory sessionFactory) {
		this.setSessionFactory(sessionFactory);
	}
	
	
	
	@SuppressWarnings("unchecked")
	@Override
	public List<News> findAll()
	{
		return this.getSession().createQuery("from News order by time DESC").list();
				
	}

	@SuppressWarnings("unchecked")
	@Override
	public Pager<News> find() {
		int size = SystemContext.getSize();
		int offset = SystemContext.getOffset();
		//按照降序方式排列，最先插入的新闻呈现在最上面
		Query query = this.getSession().createQuery("from News order by time DESC");
		query.setFirstResult(offset).setMaxResults(size);
		List<News> datas = query.list();
		Pager<News> us = new Pager<News>();
		us.setDatas(datas);
		us.setOffset(offset);
		us.setSize(size);
		//下面的sql语句使用的不是table名，而是类名"News"
		long total = (Long)this.getSession()
					.createQuery("select count(*) from News")
					.uniqueResult();
		us.setTotal(total);
		return us;
	}
	@SuppressWarnings("unchecked")
	@Override
	public Pager<News> findDeclared() {
		int size = SystemContext.getSize();
		int offset = SystemContext.getOffset();
		//按照降序方式排列，最先插入的新闻呈现在最上面
		Query query = this.getSession().createQuery("from News where state=? order by time DESC").setParameter(0, 1);
		query.setFirstResult(offset).setMaxResults(size);
		List<News> datas = query.list();
		Pager<News> us = new Pager<News>();
		us.setDatas(datas);
		us.setOffset(offset);
		us.setSize(size);
		//下面的sql语句使用的不是table名，而是类名"News"
		long total = (Long)this.getSession()
					.createQuery("select count(*) from News where state=?").setParameter(0, 1)
					.uniqueResult();
		us.setTotal(total);
		return us;
	}
@Override
public void add(News news)
{
	this.getHibernateTemplate().save(news);
}
@Override
public News getById(int id)
{
	return (News) this.getSession().createQuery("from News where id=?")
			.setParameter(0, id).uniqueResult();
}
@Override
public void delete(News news)
{
	this.getHibernateTemplate().delete(news);
}
//查找时输入的时间精确到天，数据库中精确到秒，所以这里做了一个字符串的匹配
@SuppressWarnings("unchecked")
@Override
public Pager<News> getByTime(String time)
{
	int size = SystemContext.getSize();
	int offset = SystemContext.getOffset();
	//按照降序方式排列，最先插入的新闻呈现在最上面
	Query query = this.getSession().createQuery("from News where time like ? order by time DESC")
			.setParameter(0, time+"%");
	query.setFirstResult(offset).setMaxResults(size);
	List<News> datas = query.list();
	Pager<News> us = new Pager<News>();
	us.setDatas(datas);
	us.setOffset(offset);
	us.setSize(size);
	//下面的sql语句使用的不是table名，而是类名"News"
	long total = (Long)this.getSession().createQuery(" select count(*) from News where time like ?")
			.setParameter(0, time+"%").uniqueResult();
	us.setTotal(total);
	return us;
	
}
//根据发布类型获取新闻
@SuppressWarnings("unchecked")
@Override
public Pager<News> getDeclaredNews(int state)
{
	int size = SystemContext.getSize();
	int offset = SystemContext.getOffset();
	//按照降序方式排列，最先插入的新闻呈现在最上面
	Query query = this.getSession().createQuery("from News where state=? order by time DESC")
			.setParameter(0, state);
	query.setFirstResult(offset).setMaxResults(size);
	List<News> datas = query.list();
	Pager<News> us = new Pager<News>();
	us.setDatas(datas);
	us.setOffset(offset);
	us.setSize(size);
	//下面的sql语句使用的不是table名，而是类名"News"
	long total = (Long)this.getSession().createQuery(" select count(*) from News where state=?")
			.setParameter(0, state).uniqueResult();
	us.setTotal(total);
	return us;
	
}
@Override
public void changeState(int id)
{
	if(this.getById(id).getState()==1)
	{
		//这里用到是news而不是News
		this.getSession().createSQLQuery("update news set state=0 where id=?")
		.setParameter(0, id).executeUpdate();
	}
	else
	{
		this.getSession().createSQLQuery("update news set state=1 where id=?")
		.setParameter(0, id).executeUpdate();
	}


}
@Override
public void upadteContent(News oldone,News newone)
{
	oldone.setTitle(newone.getTitle());
	oldone.setContent(newone.getContent());
	oldone.setPicture(newone.getPicture());
	oldone.setIntroduce(newone.getIntroduce());
	this.getHibernateTemplate().update(oldone);
	
}
}
