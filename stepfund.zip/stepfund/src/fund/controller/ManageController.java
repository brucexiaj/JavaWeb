package fund.controller;

import java.io.BufferedInputStream;
import java.io.ByteArrayInputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.io.UnsupportedEncodingException;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Properties;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import javax.ws.rs.PathParam;

import org.apache.commons.io.FileUtils;
import org.springframework.http.HttpRequest;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.multipart.MultipartFile;

import fund.model.Admin;
import fund.model.Inform;
import fund.model.News;
import fund.model.NewsUse;
import fund.page.Pager;
import fund.service.IAdminService;
import fund.service.INewsService;

@Controller
public class ManageController {
	private INewsService newsService;
	private IAdminService adminService;
	public IAdminService getAdminService() {
		return adminService;
	}
	@Resource
	public void setAdminService(IAdminService adminService) {
		this.adminService = adminService;
	}
	public INewsService getNewsService() {
		return newsService;
	}
	@Resource
	public void setNewsService(INewsService newsService) {
		this.newsService = newsService;
	}
	//跳转到管理员登录页面
	@RequestMapping(value="/login",method=RequestMethod.GET)
	public String admin(Model model) {
		return "/WEB-INF/jsp/administrator/login.jsp";
	}
	
@RequestMapping(value="/login",method=RequestMethod.POST)
public String administratorCheck(String username,String password,HttpSession session,Model model)
{
	String truePassword=adminService.getPass().getPassword();
	MD5 md5=new MD5();
	password=md5.transFormMD5(password);
	if(username.equals("step")&password.equals(truePassword))
	{
		//存入session，进行登录验证,后一个字符串是value
		session.setAttribute("adminName", "xiajun");
		
		return "/WEB-INF/jsp/administrator/add2.jsp";
		
	}
	else
	{
		model.addAttribute("notice","密码错误");
		return "/WEB-INF/jsp/administrator/login.jsp";
	}
}
//跳转到增加页面
@RequestMapping(value="/admin/add")
public String addNews(Model model)
{
	
	
	return "/WEB-INF/jsp/administrator/add2.jsp";

}

//跳转到编辑页面
@RequestMapping(value="/admin/edit")
public String editNews(Model model)
{
	
	model.addAttribute("pagers2", newsService.find());
	
	return "/WEB-INF/jsp/administrator/operate.jsp";

}
//跳转到预览页面
@RequestMapping(value="/admin/check")
public String checkNews(Model model)
{
	
	model.addAttribute("pagers", newsService.findDeclared());
	return "/WEB-INF/jsp/administrator/check.jsp";

}
//跳转到密码修改 页面
@RequestMapping(value="/admin/changepassword")
public String changePassword(Model model)
{
	
	
	return "/WEB-INF/jsp/administrator/changePassword.jsp";

}


//保存并发布内容
@RequestMapping(value="/admin/declare")
public String saveNews(MultipartFile attach,HttpServletRequest req,String title,String introduce,Model model,String x,String y,String w,String h)
{
	
	String content=req.getParameter("content1");
	//对图片大小进行限制
	if(attach.getSize()==0)
	{
		model.addAttribute("notice","请选择图片!");
		
		return "/WEB-INF/jsp/administrator/add2.jsp";
	}
	if(attach.getSize()>5000000)
	{
		model.addAttribute("notice","图片大于5M!");
		
		return "/WEB-INF/jsp/administrator/add2.jsp";
	}
	//对文本框为空的检测
	if(title.isEmpty())
	{
		model.addAttribute("notice","请输入标题!");
		
		return "/WEB-INF/jsp/administrator/add2.jsp";
	}
	if(introduce.isEmpty())
	{
		model.addAttribute("notice","请输入简介!");
		
		return "/WEB-INF/jsp/administrator/add2.jsp";
	}
	if(content.isEmpty())
	{
		model.addAttribute("notice","请输入正文!");
		
		return "/WEB-INF/jsp/administrator/add2.jsp";
	}

	
	String realpath=this.GetValueByKey();
	//先存入裁剪之前的图片
	File f2=new File(realpath+"/"+attach.getOriginalFilename());
	try {
		FileUtils.copyInputStreamToFile(attach.getInputStream(),f2);
	
	} catch (IOException e) {
		
		e.printStackTrace();
	}
	double x2=Double.parseDouble(x);
	int x1=(int)x2;
	double y2=Double.parseDouble(y);
	int y1=(int)y2;
	double w2=Double.parseDouble(w);
	int w1=(int)w2;
	double h2=Double.parseDouble(h);
	int h1=(int)h2;
	//对图片进行处理
	File newfile=ImgCut.imgCut(realpath+"/"+attach.getOriginalFilename(),x1,y1,w1,h1);
	
	
	
	News news=new News(1,title,content,realpath+"/"+newfile.getName(),introduce);
	
	newsService.add(news);
	//添加完成后，利用model进行提醒
	model.addAttribute("notice","发布成功!");

	return "/WEB-INF/jsp/administrator/add2.jsp";
}
//保存但不发布内容
@RequestMapping(value="/admin/notdeclare",method=RequestMethod.POST)
public String saveNewsNot(MultipartFile attach,HttpServletRequest req,String title,String introduce,Model model,String x,String y,String w,String h)
{
	double x2=Double.parseDouble(x);
	int x1=(int)x2;
	double y2=Double.parseDouble(y);
	int y1=(int)y2;
	double w2=Double.parseDouble(w);
	int w1=(int)w2;
	double h2=Double.parseDouble(h);
	int h1=(int)h2;
	String content=req.getParameter("content1");
	//对图片大小进行限制
	if(attach.getSize()==0)
	{
		model.addAttribute("notice","请选择图片!");
		
		return "/WEB-INF/jsp/administrator/add2.jsp";
	}
	if(attach.getSize()>5000000)
	{
		model.addAttribute("notice","图片大于5M!");
		
		return "/WEB-INF/jsp/administrator/add2.jsp";
	}
	//对文本框为空的检测
		if(title.isEmpty())
		{
			model.addAttribute("notice","请输入标题!");
			
			return "/WEB-INF/jsp/administrator/add2.jsp";
		}
		if(introduce.isEmpty())
		{
			model.addAttribute("notice","请输入简介!");
			
			return "/WEB-INF/jsp/administrator/add2.jsp";
		}
		if(content.isEmpty())
		{
			model.addAttribute("notice","请输入正文!");
			
			return "/WEB-INF/jsp/administrator/add2.jsp";
		}

    //添加图片文件
		String realpath=this.GetValueByKey();
		//先存入裁剪之前的图片
		File f2=new File(realpath+"/"+attach.getOriginalFilename());
		try {
			FileUtils.copyInputStreamToFile(attach.getInputStream(),f2);
		
		} catch (IOException e) {
			
			e.printStackTrace();
		}
		//对图片进行处理
		File newfile=ImgCut.imgCut(realpath+"/"+attach.getOriginalFilename(),x1,y1,w1,h1);
		
		
		
		News news=new News(0,title,content,realpath+"/"+newfile.getName(),introduce);
		
		newsService.add(news);
		//添加完成后，利用model进行提醒
		model.addAttribute("notice","保存成功!");

		return "/WEB-INF/jsp/administrator/add2.jsp";
}

//获取已发布的内容
@RequestMapping(value="/admin/declarednews")
public String getDeclared(Model model)
{
	//这里没有数据库的操作，不做提醒
	model.addAttribute("notice","筛选成功");
	model.addAttribute("pagers2", newsService.getDeclaredNews(1));
	return "/WEB-INF/jsp/administrator/operate.jsp";
}
//获取未发布的内容
@RequestMapping(value="/admin/notdeclarednews")
public String getNotDeclared(Model model)
{
	//这里没有数据库的操作，不做提醒
	model.addAttribute("notice","筛选成功");
	model.addAttribute("pagers2", newsService.getDeclaredNews(0));
	return "/WEB-INF/jsp/administrator/operate.jsp";
}
//修改状态
@RequestMapping(value="/admin/{id}/updatestate")
public String updateState(Model model,@PathVariable int id)
{
	newsService.changeState(id);
	model.addAttribute("pagers2", newsService.find());
	model.addAttribute("notice","修改成功");
	
	return "/WEB-INF/jsp/administrator/operate.jsp";
}
//批量发布
@RequestMapping(value="/admin/multideclare")
public String multiDeclare(Model model,HttpServletRequest request)
{
	
	String  userid[]   =  request.getParameterValues("userid");
	
	int multi[]=new int[userid.length];
	for(int i=0;i<userid.length;i++)
	{
		multi[i]=Integer.parseInt(userid[i]);
		if(newsService.getById(multi[i]).getState()==0);
		{
			newsService.changeState(multi[i]);
		}
		
	}
	model.addAttribute("notice","发布成功");
	model.addAttribute("pagers2", newsService.find());
	return "/WEB-INF/jsp/administrator/operate.jsp";
}
//批量取消发布
@RequestMapping(value="/admin/multinotdeclare")
public String multiNotDeclare(Model model,HttpServletRequest request)
{
	
	String  userid[]   =  request.getParameterValues("userid");
	
	int multi[]=new int[userid.length];
	for(int i=0;i<userid.length;i++)
	{
		multi[i]=Integer.parseInt(userid[i]);
		if(newsService.getById(multi[i]).getState()==1);
		{
			newsService.changeState(multi[i]);
		}
		
	}
	model.addAttribute("notice","取消成功!");
	model.addAttribute("pagers2", newsService.find());
	return "/WEB-INF/jsp/administrator/operate.jsp";
}
//跳转到内容更新页面
@RequestMapping(value="/admin/{id}/updatecontent")
public String updateContent(Model model,@PathVariable int id)
{
	
	model.addAttribute("newsList", newsService.getById(id));
	return "/WEB-INF/jsp/administrator/updateContent.jsp";
}
//提交修改结果，完成修改
@RequestMapping(value="/admin/updatecontentsubmit")
public String updateContentSubmit(MultipartFile attach,HttpServletRequest req,int id,String title,String introduce,Model model,String x,String  y,String  w,String  h)
{
	String content=req.getParameter("content1");
	if(title.length()==0)
	{
		model.addAttribute("newsList", newsService.getById(id));
		model.addAttribute("notice","请输入标题!");
		
		return "/WEB-INF/jsp/administrator/updateContent.jsp";
	}
	if(introduce.isEmpty())
	{
		model.addAttribute("newsList", newsService.getById(id));
		model.addAttribute("notice","请输入简介!");
		
		return "/WEB-INF/jsp/administrator/updateContent.jsp";
	}
	if(content.length()==0)
	{
		model.addAttribute("newsList", newsService.getById(id));
		model.addAttribute("notice","请输入内容!");
		
		return "/WEB-INF/jsp/administrator/updateContent.jsp";
	}
	
	String realpath=this.GetValueByKey();
	//如果有图片，再将新图片写入
	if(!attach.isEmpty())
	{
	
		//先存入裁剪之前的图片
				File f2=new File(realpath+"/"+attach.getOriginalFilename());
				try {
					FileUtils.copyInputStreamToFile(attach.getInputStream(),f2);
				
				} catch (IOException e) {
					
					e.printStackTrace();
				}
				double x2=Double.parseDouble(x);
				int x1=(int)x2;
				double y2=Double.parseDouble(y);
				int y1=(int)y2;
				double w2=Double.parseDouble(w);
				int w1=(int)w2;
				double h2=Double.parseDouble(h);
				int h1=(int)h2;
				//对图片进行处理
				File newfile=ImgCut.imgCut(realpath+"/"+attach.getOriginalFilename(),x1,y1,w1,h1);
				
				
	
	News oldone=newsService.getById(id);
	
	News newone=new News(id,oldone.getState(),title,content,realpath+"/"+newfile.getName(),introduce);
	
	newsService.upadteContent(oldone,newone);
	//newsService.add(news);
	}
	
	//如果没有修改图片
	if(attach.isEmpty())
	{
		News oldone=newsService.getById(id);
		
		News newone=new News(id,oldone.getState(),title,content,oldone.getPicture(),introduce);
		
		newsService.upadteContent(oldone,newone);
		
	}
	
	
	
	
	model.addAttribute("notice","修改成功!");
	model.addAttribute("pagers2", newsService.find());
	return "/WEB-INF/jsp/administrator/operate.jsp";
}
//跳转到具体内容的修改页面
@RequestMapping(value="/admin/{id}/update")
public String update(Model model,@PathVariable int id)
{
	News news=newsService.getById(id);
	model.addAttribute("news",news);
	return "/WEB-INF/jsp/administrator/update.jsp";
}
//提交修改结果，完成修改
@RequestMapping(value="/admin/updatesubmit")
public String saveUpdate(MultipartFile attach,HttpServletRequest req,int id,String title,String content,Model model)
{
	//确定时间格式，生成当前时间
	SimpleDateFormat df = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
	Date currentTime=new Date();
	String time=df.format(currentTime);
	
	//添加图片文件
    String realpath=req.getSession().getServletContext().getRealPath("/resoures/image");
	System.out.println("realpath:"+realpath);
	
	//System.out.println("filename:"+attach.getOriginalFilename());
	//如果有图片，再将新图片写入
	if(!attach.isEmpty())
	{
	
		File f=new File(realpath+"/"+attach.getOriginalFilename());
	try {
		FileUtils.copyInputStreamToFile(attach.getInputStream(),f);
	} catch (IOException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
	
	//News news=new News(title,content,time,attach.getOriginalFilename());
	//找到旧版的新闻并删除，然后再添加修改后的新闻
	News old=newsService.getById(id);
	newsService.delete(old);
	//newsService.add(news);
	}
	
	//如果没有修改图片
	if(attach.isEmpty())
	{
		
		String picturePath=newsService.getById(id).getPicture();
		//News news=new News(title,content,time,picturePath);
		//找到旧版的新闻并删除，然后再添加修改后的新闻
		News old=newsService.getById(id);
		newsService.delete(old);
		//newsService.add(news);
	}
	
	
	
	//修改成功提醒
	Inform inform=new Inform("修改成功!");
	model.addAttribute("information",inform);
	model.addAttribute("newsList", newsService.findAll());
	return "/WEB-INF/jsp/administrator/deleteOrRevise.jsp";
}

//通过时间筛选
@RequestMapping(value="/admin/searchviatime")
public String saveUpdate(Model model,String year,String month,String date)
{
	model.addAttribute("pagers2",newsService.getByTime(year+"-"+month+"-"+date));
	//如果查找结果是空，输出查找失败提示
	if(newsService.getByTime(year+"-"+month+"-"+date).getTotal()==0)
	{
		
		model.addAttribute("notice","没有内容");
		return "/WEB-INF/jsp/administrator/operate.jsp";
	}
	else
	{
		Inform inform=new Inform("查找成功");
		model.addAttribute("notice","查找成功");
		return "/WEB-INF/jsp/administrator/operate.jsp";
	}
	
}
//删除
@RequestMapping(value="/admin/{id}/delete")
public String delete(Model model,@PathVariable int id)
{
	News news=newsService.getById(id);
	newsService.delete(news);
	//删除成功，加入提醒信息
	Inform inform=new Inform("删除成功");
	model.addAttribute("information",inform);
	model.addAttribute("newsList", newsService.findAll());
	return "/WEB-INF/jsp/administrator/deleteOrRevise.jsp";
}
//管理员退出登录
@RequestMapping(value="/admin/logout")
public String logout()
{
	return "/WEB-INF/jsp/administrator/login.jsp";
}
@RequestMapping(value="/logout")
public String logout2()
{
	return "/WEB-INF/jsp/administrator/login.jsp";
}
//提交修改密码
@RequestMapping(value="/admin/submitpassword")
public String submitPassword(Model model,String oldpassword,String newpassword,String surepassword)
{
	String truePassword=adminService.getPass().getPassword();
	MD5 tm1 = new MD5();
	
	if(oldpassword.length()==0)
	{
		model.addAttribute("notice","请输入原密码");
		return "/WEB-INF/jsp/administrator/changePassword.jsp";
	}
	if(newpassword.length()==0)
	{
		model.addAttribute("notice","请输入新密码");
		return "/WEB-INF/jsp/administrator/changePassword.jsp";
	}
	if(surepassword.length()==0)
	{
		model.addAttribute("notice","请输入新密码");
		return "/WEB-INF/jsp/administrator/changePassword.jsp";
	}
	
	oldpassword=tm1.transFormMD5(oldpassword);
	newpassword=tm1.transFormMD5(newpassword);
	surepassword=tm1.transFormMD5(surepassword);
	if(!truePassword.equals(oldpassword))
	{
		model.addAttribute("notice","原密码有误!");
		return "/WEB-INF/jsp/administrator/changePassword.jsp";
	}
	
	if(!newpassword.equals(surepassword))
	{
		model.addAttribute("notice","两次密码不一致!");
		return "/WEB-INF/jsp/administrator/changePassword.jsp";
	}
	

	

	
	
	adminService.updatePassword(newpassword);
	
	model.addAttribute("notice","修改密码成功!");
	return "/WEB-INF/jsp/administrator/changePassword.jsp";
}
//读取properties文件，返回设置的图片存放位置
public  String GetValueByKey()
{
	String key="filePath";
	//String dir = System.getProperty("user.dir");
	//System.out.println("dir:"+dir);
	//String dir2 = dir+ File.separator +"MyWorkSpace" + File.separator + "stepfund" +File.separator + "src"
     //       + File.separator + "filedir.properties";
	//System.out.println("dir2:"+dir2);
    Properties pps = new Properties();
    try {
    	//读取properties的另一种方式
    	InputStream in = this.getClass().getResourceAsStream("/filedir.properties");
         //InputStream in = new BufferedInputStream (new FileInputStream(dir2));  
         pps.load(in);
         String value = pps.getProperty(key);
         in.close();
         return value;
        }
    catch (IOException e)
    {
        e.printStackTrace();
        return null;
    }
}

@RequestMapping(value="/admin/showpicture",method = RequestMethod.GET)  
public void showPicture(@PathParam("path")String path,HttpServletRequest request,HttpServletResponse response,Model model) throws IOException{  
	
    String pic_path = path;
    System.out.println(pic_path);
    FileInputStream is = new FileInputStream(pic_path);
    int i = is.available(); // 得到文件大小
    byte data[] = new byte[i];
    is.read(data); // 读数据
    is.close();
    response.setContentType("image/*"); // 设置返回的文件类型
    OutputStream toClient = response.getOutputStream(); // 得到向客户端输出二进制数据的对象
    toClient.write(data); // 输出数据
    toClient.close();
}
@RequestMapping(value="/showpicture",method = RequestMethod.GET)  
public void showPictureInNews(@PathParam("path")String path,HttpServletRequest request,HttpServletResponse response,Model model) throws IOException{  
	
    String pic_path = path;
    System.out.println(pic_path);
    FileInputStream is = new FileInputStream(pic_path);
    int i = is.available(); // 得到文件大小
    byte data[] = new byte[i];
    is.read(data); // 读数据
    is.close();
    response.setContentType("image/*"); // 设置返回的文件类型
    OutputStream toClient = response.getOutputStream(); // 得到向客户端输出二进制数据的对象
    toClient.write(data); // 输出数据
    toClient.close();
}

}
