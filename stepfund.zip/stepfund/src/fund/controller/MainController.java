package fund.controller;

import javax.annotation.Resource;


import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;

import fund.model.News;
import fund.service.INewsService;

@Controller
public class MainController {
	public INewsService newsService;
	public INewsService getNewsService() {
		return newsService;
	}
	@Resource
	public void setNewsService(INewsService newsService) {
		this.newsService = newsService;
	}
/*
 * 直接运行或者输入index都能够到达首页
 */
@RequestMapping(value="/index")
public String welcomePage()
{
	return "/index.jsp";
}

/*
 * 关于我们栏目
 */
@RequestMapping(value="/news")
public String displayNews(Model model)
{
	
	//将数据传入视图层
	model.addAttribute("pagers", newsService.findDeclared());
	return "/WEB-INF/jsp/news.jsp";
}
@RequestMapping(value="/{id}/details")
public String displayDetails(Model model,@PathVariable int id)
{
	News news=newsService.getById(id);
	model.addAttribute("newsList",news);
	
	return "/WEB-INF/jsp/details.jsp";
}
//调到关于我们中基金简洁页面
@RequestMapping(value="/about/brief")
public String displayAbout(Model model)
{
	
	
	return "/WEB-INF/jsp/aboutIntroduce.jsp";
}
//调到关于我们中投资特点页面
@RequestMapping(value="/about/attribute")
public String investTraint(Model model)
{
	
	
	return "/WEB-INF/jsp/investTraint.jsp";
}
//调到关于我们中投后管理页面
@RequestMapping(value="/about/manage")
public String investManage(Model model)
{
	
	
	return "/WEB-INF/jsp/investManage.jsp";
}
//调到关于我们中基金荣誉页面
@RequestMapping(value="/about/honor")
public String fundHonor(Model model)
{
	
	
	return "/WEB-INF/jsp/fundHonor.jsp";
}
//调到团队页面
@RequestMapping(value="/group")
public String displayGroup(Model model)
{
	
	
	return "/WEB-INF/jsp/group.jsp";
}
@RequestMapping(value="/all")
public String displayAllCompany(Model model)
{
	
	
	return "/WEB-INF/jsp/company0.jsp";
}
//调到公司页面1
@RequestMapping(value="/company1")
public String displayCompany(Model model)
{
	
	
	return "/WEB-INF/jsp/company.jsp";
}
//调到公司页面2
@RequestMapping(value="/company2")
public String displayCompany2(Model model)
{
	
	
	return "/WEB-INF/jsp/company2.jsp";
}
//调到公司页面3
@RequestMapping(value="/company3")
public String displayCompany3(Model model)
{
	
	
	return "/WEB-INF/jsp/company3.jsp";
}
//调到公司页面4
@RequestMapping(value="/company4")
public String displayCompany4(Model model)
{
	
	
	return "/WEB-INF/jsp/company4.jsp";
}
}
