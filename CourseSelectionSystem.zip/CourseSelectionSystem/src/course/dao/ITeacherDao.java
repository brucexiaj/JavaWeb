package course.dao;

import course.model.Teacher;


public interface ITeacherDao {
	
	
	
	public Teacher loadByTeacherCode(String code);
}
