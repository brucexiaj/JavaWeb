package course.dao;

import java.util.ArrayList;
import java.util.List;

import javax.annotation.Resource;










import org.hibernate.SessionFactory;
import org.springframework.orm.hibernate3.support.HibernateDaoSupport;
import org.springframework.stereotype.Repository;

import course.model.Grade;



@Repository("gradeDao")
public class GradeDao extends HibernateDaoSupport implements IGradeDao {
	@Resource
	public void setSuperSessionFactory(SessionFactory sessionFactory) {
		this.setSessionFactory(sessionFactory);
	}
	
	
	@Override
	public List<Grade> ShowGradeViaStudentCode(String student_code)
	{
		List<Grade> gradeList=new ArrayList();
		gradeList= this.getSession().createQuery("from Grade where grade_student=?")
				.setParameter(0, student_code).list();
		
		return gradeList;
	}
	@Override
	public void save(Grade grade)
	{
		this.getHibernateTemplate().save(grade);
	
	}
	@Override
	
	public void delete(Grade grade)
	
	{
		this.getHibernateTemplate().delete(grade);
	}
	@Override
	public List<Grade> showViaStudentPlusCourse(String studentCode,String courseCode)
	{
		
		List<Grade> gradeList1= this.getSession().createQuery("from Grade where grade_student=?")
				.setParameter(0, studentCode).list();
		List<Grade> gradeList2= this.getSession().createQuery("from Grade where grade_course=?")
				.setParameter(0, courseCode).list();
		//求出这两个List的交集
		gradeList1.retainAll(gradeList2);
		
		return gradeList1;
	}

}
