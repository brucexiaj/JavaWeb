package course.dao;

import java.util.ArrayList;
import java.util.List;

import javax.annotation.Resource;









import org.hibernate.SessionFactory;
import org.springframework.orm.hibernate3.support.HibernateDaoSupport;
import org.springframework.stereotype.Repository;

import course.model.Course;
import course.model.Grade;
import course.model.Student;

@Repository("courseDao")
public class CourseDao extends HibernateDaoSupport implements ICourseDao {
	@Resource
	public void setSuperSessionFactory(SessionFactory sessionFactory) {
		this.setSessionFactory(sessionFactory);
	}
	
	@Override
	public List<Course> ShowCourse(String code[])
	{
		List<Course> courseList=new ArrayList();
		for(int i=0;i<code.length;i++)
		{
			String course_code=code[i];
			Course course=(Course)this.getSession().createQuery("from Course where course_code=?")
					.setParameter(0, course_code).uniqueResult();
			courseList.add(course);
		}
		
		return courseList;
	}
	@Override
	public Course loadByCourseCode(String code)
	{
		return (Course)this.getSession().createQuery("from Course where course_code=?")
				.setParameter(0, code).uniqueResult();
	}
	@Override
	public List<Course> findAll()
	{
		return (List<Course>) this.getSession().createQuery("from Course").list();
				
	}
	@Override
	public List<Course> searchviatime(String time)
	{
		return this.getSession().createQuery("from Course where course_time=?")
				.setParameter(0, time).list();
	}
	@Override
	public List<Course> searchviacategory(String category)
	{
		return this.getSession().createQuery("from Course where course_category=?")
				.setParameter(0,category).list();
	}
}
