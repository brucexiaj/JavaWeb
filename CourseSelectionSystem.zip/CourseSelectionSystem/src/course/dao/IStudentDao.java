package course.dao;

import course.model.Student;


public interface IStudentDao {
	
	
	
	public Student loadByStudentname(String student_name);
	public Student loadByStudentCode(String code);
	public void updatepassword(String code,String new_password);
	public void save(Student s);
}
