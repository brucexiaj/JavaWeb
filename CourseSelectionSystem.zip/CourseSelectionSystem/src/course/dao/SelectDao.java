package course.dao;

import java.util.ArrayList;
import java.util.List;

import javax.annotation.Resource;






import org.hibernate.SessionFactory;
import org.springframework.orm.hibernate3.support.HibernateDaoSupport;
import org.springframework.stereotype.Repository;

import course.model.Select1;
import course.model.Student;

@Repository("selectDao")
public class SelectDao extends HibernateDaoSupport implements ISelectDao {
	@Resource
	public void setSuperSessionFactory(SessionFactory sessionFactory) {
		this.setSessionFactory(sessionFactory);
	}
	
	@Override
	public List<Select1> ShowCourseCodeViaCode(String code)
	{
		List<Select1> selectList=new ArrayList();
		selectList=(List<Select1>)this.getSession().createQuery("from Select1 where select_student=?")
				.setParameter(0, code).list();
		return selectList;
	}
	@Override
	public void save(Select1 select1)
	{
		this.getHibernateTemplate().save(select1);
	}
    @Override
    public List<Select1> ShowViaCoursePlusStudent(String studentCode,String courseCode)
    {
    	List<Select1> deleteList1=this.getSession().createQuery("from Select1 where select_student=?")
				.setParameter(0, studentCode).list();
    	List<Select1> deleteList2=this.getSession().createQuery("from Select1 where select_course=?")
				.setParameter(0, courseCode).list();
    	deleteList1.retainAll(deleteList2);
    	return deleteList1;
    }
    @Override
    public void delete(Select1 select1)
    {
      this.getHibernateTemplate().delete(select1);	
    }
    
}
