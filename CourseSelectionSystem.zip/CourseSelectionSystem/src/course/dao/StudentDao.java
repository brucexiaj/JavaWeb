package course.dao;

import java.io.UnsupportedEncodingException;

import javax.annotation.Resource;






import org.hibernate.SessionFactory;
import org.springframework.orm.hibernate3.support.HibernateDaoSupport;
import org.springframework.stereotype.Repository;

import course.model.Student;

@Repository("studentDao")
public class StudentDao extends HibernateDaoSupport implements IStudentDao {
	@Resource
	public void setSuperSessionFactory(SessionFactory sessionFactory) {
		this.setSessionFactory(sessionFactory);
	}
	@Override
	public Student loadByStudentCode(String code)
	{
	return (Student)this.getSession().createQuery("from Student where student_code=?")
				.setParameter(0, code).uniqueResult();
	}
	@Override
	public Student loadByStudentname(String student_name) {
		return (Student)this.getSession().createQuery("from Student where student_name=?")
				.setParameter(0, student_name).uniqueResult();
	}
	@Override
	public void updatepassword(String code,String new_password)
	{
		String student_true = null;
		Student s=(Student) this.getSession().createQuery("from Student where student_code=?")
				.setParameter(0, code).uniqueResult();
		try {
			student_true=new String(s.getStudent_true().getBytes("UTF-8"),"UTF-8");
		} catch (UnsupportedEncodingException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	Student new_student=new Student(s.getStudent_name(),new_password,s.getStudent_code(),s.getStudent_email(),s.getStudent_idcard(),student_true);
	this.getHibernateTemplate().delete(s);
	this.getHibernateTemplate().save(new_student);
	}
	@Override
	public void save(Student s)
	{
		this.getHibernateTemplate().save(s);
	}

}
