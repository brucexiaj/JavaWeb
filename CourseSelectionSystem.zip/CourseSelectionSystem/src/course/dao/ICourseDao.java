package course.dao;
import java.util.List;

import course.model.Course;
import course.model.Grade;



public interface ICourseDao {
	
	
	
	public List<Course> ShowCourse(String code[]);
	public Course loadByCourseCode(String code);
	public List<Course> findAll();
	public List<Course> searchviatime(String time);
	public List<Course> searchviacategory(String category);
}
