package course.dao;

import javax.annotation.Resource;




import org.hibernate.SessionFactory;
import org.springframework.orm.hibernate3.support.HibernateDaoSupport;
import org.springframework.stereotype.Repository;

import course.model.Student;
import course.model.Teacher;

@Repository("teacherDao")
public class TeacherDao extends HibernateDaoSupport implements ITeacherDao {
	@Resource
	public void setSuperSessionFactory(SessionFactory sessionFactory) {
		this.setSessionFactory(sessionFactory);
	}
	
	@Override
	public Teacher loadByTeacherCode(String code) {
		return (Teacher)this.getSession().createQuery("from Teacher where teacher_code=?")
				.setParameter(0, code).uniqueResult();
	}

}
