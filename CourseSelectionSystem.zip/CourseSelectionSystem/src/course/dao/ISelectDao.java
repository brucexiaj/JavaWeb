package course.dao;
import java.util.List;

import course.model.Grade;
import course.model.Select1;



public interface ISelectDao {
	
	
	
	public List<Select1> ShowCourseCodeViaCode(String student_code);
	public void save(Select1 select1);
	public List<Select1> ShowViaCoursePlusStudent(String studentCode,String courseCode);
	public void delete(Select1 select1);
}
