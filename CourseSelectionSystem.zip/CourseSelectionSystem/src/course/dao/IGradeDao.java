package course.dao;
import java.util.List;

import course.model.Grade;



public interface IGradeDao {
	
	
	
	public List<Grade> ShowGradeViaStudentCode(String student_code);
	public void save(Grade grade);
	public void delete(Grade grade);
	public List<Grade> showViaStudentPlusCourse(String studentCode,String courseCode);
}
