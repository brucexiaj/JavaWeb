package course.service;

import java.util.List;

import javax.annotation.Resource;

import org.springframework.stereotype.Service;

import course.dao.ICourseDao;
import course.dao.IStudentDao;
import course.exception.StudentException;
import course.model.Course;
import course.model.Student;

@Service("courseService")
public class CourseService implements ICourseService {

	private ICourseDao courseDao;
	
	
	
	public ICourseDao getCourseDao() {
		return courseDao;
	}
@Resource
	public void setCourseDao(ICourseDao courseDao) {
		this.courseDao = courseDao;
	}

	
	

@Override
public List<Course> ShowCourse(String code[])
{
	return courseDao.ShowCourse(code);
}
	@Override
public Course loadByCourseCode(String code)
{
	return courseDao.loadByCourseCode(code);
}
	@Override
	public List<Course> findAll()
	{
		return courseDao.findAll();
	}
@Override
public List<Course> searchviatime(String time)
{
	return courseDao.searchviatime(time);
}
@Override
public List<Course> searchviacategory(String category)
{
	return courseDao.searchviacategory(category);
}



}
