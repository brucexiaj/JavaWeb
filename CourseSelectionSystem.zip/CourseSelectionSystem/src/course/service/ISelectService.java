package course.service;

import java.util.List;

import course.model.Select1;
import course.model.Student;


public interface ISelectService {
	
	
	public List<Select1> showbystudent(String student_code);
	public void save(Select1 select1);
	public List<Select1> ShowViaCoursePlusStudent(String studentCode,String courseCode);
	public void delete(Select1 select1);
	
}
