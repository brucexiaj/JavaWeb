package course.service;

import java.util.List;

import course.model.Course;
import course.model.Grade;;


public interface ICourseService {
	
	
		public List<Course> ShowCourse(String code[]);
		public Course loadByCourseCode(String code);
		public List<Course> findAll();
		public List<Course> searchviatime(String time);
		public List<Course> searchviacategory(String category);
}
