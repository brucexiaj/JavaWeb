package course.service;

import java.util.List;



import javax.annotation.Resource;

import org.springframework.stereotype.Service;

import course.dao.IGradeDao;
import course.dao.ISelectDao;
import course.model.Grade;
import course.model.Select1;
import course.model.Student;


@Service("selectService")
public class SelectService implements ISelectService {
	private ISelectDao selectDao;
	
	public ISelectDao getSelectDao() {
		return selectDao;
	}
	@Resource
	public void setSelectDao(ISelectDao selectDao) {
		this.selectDao = selectDao;
	}
	
@Override
public List<Select1> showbystudent(String student_code)
{
	return selectDao.ShowCourseCodeViaCode(student_code);
}
@Override
public void save(Select1 select1)
{
	selectDao.save(select1);
}
@Override
public List<Select1> ShowViaCoursePlusStudent(String studentCode,String courseCode)
{
	return selectDao.ShowViaCoursePlusStudent(studentCode, courseCode);
}
@Override
public void delete(Select1 select1)
{
	selectDao.delete(select1);
}
}
