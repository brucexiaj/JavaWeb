package course.service;

import java.util.List;

import course.model.Grade;;


public interface IGradeService {
	
	
		public List<Grade> ShowGrade(String student_code);
		public void save(Grade grade);
		public void delete(Grade grade);
		public List<Grade> showViaStudentPlusCourse(String studentCode,String courseCode);
}
