package course.service;

import course.model.Student;


public interface IStudentService {
	
	
		public Student loadByStudentName(String student_name);
		public Student loadByStudentCode(String student_code);
		public void updatepassword(String code,String new_password);
		public void save(Student s);
}
