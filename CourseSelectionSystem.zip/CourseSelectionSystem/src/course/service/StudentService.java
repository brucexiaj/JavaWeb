package course.service;

import javax.annotation.Resource;

import org.springframework.stereotype.Service;

import course.dao.IStudentDao;
import course.exception.StudentException;
import course.model.Student;

@Service("studentService")
public class StudentService implements IStudentService {

	private IStudentDao studentDao;
	
	
	
	public IStudentDao getStudentDao() {
		return studentDao;
	}

	@Resource
	public void setStudentDao(IStudentDao studentDao) {
		this.studentDao = studentDao;
	}

	

@Override
public Student loadByStudentName(String student_name){
	Student u = studentDao.loadByStudentname(student_name);
	
	return u;
}
	
public Student loadByStudentCode(String student_code)
{
	return studentDao.loadByStudentCode(student_code);
}

public void updatepassword(String code,String new_password)
{
	studentDao.updatepassword(code, new_password);
}
@Override
public void save(Student s)
{
	studentDao.save(s);
}



}
