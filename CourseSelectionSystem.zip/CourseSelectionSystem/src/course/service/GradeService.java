package course.service;

import java.util.List;

import javax.annotation.Resource;

import org.springframework.stereotype.Service;

import course.dao.IGradeDao;
import course.model.Grade;


@Service("gradeService")
public class GradeService implements IGradeService {
	private IGradeDao gradeDao;
	
	public IGradeDao getGradeDao() {
		return gradeDao;
	}
	@Resource
	public void setGradeDao(IGradeDao gradeDao) {
		this.gradeDao = gradeDao;
	}
@Override
	public List<Grade> ShowGrade(String student_code)
	{
		List<Grade> gradeList=gradeDao.ShowGradeViaStudentCode(student_code);
		return gradeList;
	}
@Override
public void save(Grade grade)
{
	gradeDao.save(grade);
}
@Override
public void delete(Grade grade)
{
	gradeDao.delete(grade);
}
@Override
public List<Grade> showViaStudentPlusCourse(String studentCode,String courseCode)
{
	return gradeDao.showViaStudentPlusCourse(studentCode, courseCode);
}
}
