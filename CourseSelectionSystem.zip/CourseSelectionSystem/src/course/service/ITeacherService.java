package course.service;

import course.model.Student;
import course.model.Teacher;


public interface ITeacherService {
	
	
		public Teacher loadByTeacherCode(String code);
}
