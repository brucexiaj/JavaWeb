package course.service;

import javax.annotation.Resource;

import org.springframework.stereotype.Service;

import course.dao.IStudentDao;
import course.dao.ITeacherDao;
import course.exception.StudentException;
import course.model.Student;
import course.model.Teacher;

@Service("teacherService")
public class TeacherService implements ITeacherService {

	private ITeacherDao teacherDao;
	
	
	
	public ITeacherDao getTeacherDao() {
		return teacherDao;
	}
	@Resource
	public void setTeacherDao(ITeacherDao teacherDao) {
		this.teacherDao = teacherDao;
	}

	

	

@Override
public Teacher loadByTeacherCode(String code){
	Teacher u = teacherDao.loadByTeacherCode(code);
	
	return u;
}
	


	



}
