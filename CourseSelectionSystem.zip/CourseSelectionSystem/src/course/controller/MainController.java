package course.controller;

import java.io.File;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.annotation.Resource;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

















import jxl.Workbook;
import jxl.write.Label;
import jxl.write.WritableSheet;
import jxl.write.WritableWorkbook;

import org.springframework.http.HttpRequest;
import org.springframework.mobile.device.Device;
import org.springframework.mobile.device.DeviceUtils;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import course.internet.Mail;
import course.model.Course;
import course.model.Grade;
import course.model.Select1;
import course.model.Student;
import course.model.Teacher;
import course.model.entity.StudentGrade;
import course.service.ICourseService;
import course.service.IGradeService;
import course.service.ISelectService;
import course.service.IStudentService;
import course.service.ITeacherService;
import course.service.SelectService;


@Controller

public class MainController {
	
	public Map<String,StudentGrade> studentGrade=new HashMap<String,StudentGrade>();
	
	private IStudentService studentService;
    private IGradeService gradeService;
    private ISelectService selectService;
    public ITeacherService getTeacherService() {
		return teacherService;
	}
    @Resource
	public void setTeacherService(ITeacherService teacherService) {
		this.teacherService = teacherService;
	}
	private ICourseService courseService;
    private ITeacherService teacherService;
	public ICourseService getCourseService() {
	return courseService;
}
	@Resource
public void setCourseService(ICourseService courseService) {
	this.courseService = courseService;
}
	public IGradeService getGradeService() {
	return gradeService;
}
public ISelectService getSelectService() {
		return selectService;
	}
@Resource
	public void setSelectService(ISelectService selectService) {
		this.selectService = selectService;
	}
@Resource
public void setGradeService(IGradeService gradeService) {
	this.gradeService = gradeService;
}

	public IStudentService getStudentService() {
		return studentService;
	}
	
	@Resource
	public void setStudentService(IStudentService studentService) {
		this.studentService = studentService;
	}
	@RequestMapping(value="/login",method=RequestMethod.GET)
	public  String login(Model model) {
		
		/* String deviceType = "未知";
		 if (device.isNormal()) {
	            deviceType = "PC端";
	        } else if (device.isMobile()) {
	            deviceType = "手机端";
	        } else if (device.isTablet()) {
	            deviceType = "平板端";
	        }
		 Student s=new Student(deviceType);
		 model.addAttribute(s);*/
		return "login";
	}
	@RequestMapping(value="/register",method=RequestMethod.GET)
	public String register(Model model)
	{
		model.addAttribute(new Student());
		return "register";
	}
	@RequestMapping(value="/register_success")
	public String register_success()
	{
		return "register_success";
	}
	//注册，这里只能验证注册的内容，并不能把错误信息传给视图层
		@RequestMapping(value="register",method=RequestMethod.POST)
		public String register(@Validated Student student,BindingResult br,String student_name,String student_password,String student_code,String student_true,String student_email,String student_idcard,String ensure_password)
			{
			   if(student_password.equals(ensure_password)&&!(br.hasErrors()))
			    {
				Student s=new Student(student_name,student_password,student_code,student_email,student_idcard,student_true);
				studentService.save(s);
				return "register_success";
			     }
			   else
			   {
				   //这里一定不要加上redirect
					return "register";
			   }
			}	
		//登录
		@RequestMapping(value="/login",method=RequestMethod.POST)
		public String login(String student_name,String student_password,String code,Model model,HttpSession session,HttpServletRequest request) {
			Student u = studentService.loadByStudentName(student_name);
			
		    
			String true_password=u.getStudent_password();
			
			//获取学生编码并存入session
			String studentCode=u.getStudent_code();
			session.setAttribute("loginstudent", studentCode);
			//检测验证码是否正确
			//如果不正确，重新返回登陆界面
			if (!(code.equalsIgnoreCase(session.getAttribute("validateCode").toString())))
			{
				return "login";
				
			}
			else
			{
			if(true_password.equals(student_password))
			{
				return "redirect:student/login_success";
			}
			else 
			{
				return "login";
			}
			}
			
		}
		//这里不知道为什么需要对login_success进行再一次映射，经过测试，如果不进行二次映射，sitmesh无法发挥作用
		@RequestMapping(value="student/login_success")
		public  String loginSuccess(Model model,HttpSession session,HttpServletRequest request)
		{
			String studentCode=(String)session.getAttribute("loginstudent");
			String ipaddress=null;
			
		    if(request.getHeader("x-forwarded-for")==null)
		    {
		    	ipaddress=request.getRemoteAddr();
		    }
		    else
		    {
		    	ipaddress=request.getHeader("x-forwarded-for");
		    }
		    Student u=studentService.loadByStudentCode(studentCode);
		    String true_password=u.getStudent_password();
			//把ip地址加进去的student
			Student ipstudent=new Student(u.getStudent_name(),u.getStudent_code(),ipaddress);
			model.addAttribute(ipstudent);
			return "student/login_success";
		}
		
		
}