package course.controller;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.annotation.Resource;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
















import javax.validation.Valid;
import javax.ws.rs.core.Application;

import jxl.Workbook;
import jxl.write.Label;
import jxl.write.WritableSheet;
import jxl.write.WritableWorkbook;

import org.springframework.http.HttpRequest;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import course.internet.Mail;
import course.model.Course;
import course.model.Grade;
import course.model.Select1;
import course.model.Student;
import course.model.Teacher;
import course.model.entity.StudentGrade;
import course.service.ICourseService;
import course.service.IGradeService;
import course.service.ISelectService;
import course.service.IStudentService;
import course.service.ITeacherService;
import course.service.SelectService;


@Controller
@RequestMapping("/student")
public class StudentController {
	
	public Map<String,StudentGrade> studentGrade=new HashMap<String,StudentGrade>();
	
	private IStudentService studentService;
    private IGradeService gradeService;
    private ISelectService selectService;
    public ITeacherService getTeacherService() {
		return teacherService;
	}
    @Resource
	public void setTeacherService(ITeacherService teacherService) {
		this.teacherService = teacherService;
	}
	private ICourseService courseService;
    private ITeacherService teacherService;
	public ICourseService getCourseService() {
	return courseService;
}
	@Resource
public void setCourseService(ICourseService courseService) {
	this.courseService = courseService;
}
	public IGradeService getGradeService() {
	return gradeService;
}
public ISelectService getSelectService() {
		return selectService;
	}
@Resource
	public void setSelectService(ISelectService selectService) {
		this.selectService = selectService;
	}
@Resource
public void setGradeService(IGradeService gradeService) {
	this.gradeService = gradeService;
}

	public IStudentService getStudentService() {
		return studentService;
	}
	
	@Resource
	public void setStudentService(IStudentService studentService) {
		this.studentService = studentService;
	}
	/*@RequestMapping(value="/login",method=RequestMethod.GET)
	public String login() {
		
		return "student/login";
	}*/

		
	
	//展示学生的分数&计算平均绩点
	@RequestMapping(value="/showgrade")
	public String showgrade(Model model,HttpSession session) {
		String student_code=(String)session.getAttribute("loginstudent");
		int totalgrade=0;
		int totalcredit=0;
		//通过学生编码找到Grade
		List<Grade> gradeList=gradeService.ShowGrade(student_code);
		//类型转化
		for(int i=0;i<gradeList.size();i++)
		{
			Grade newgrade=gradeList.get(i);
			
			//找到所有的编号
			String coursecode=newgrade.getGrade_course();
			String studentcode=newgrade.getGrade_student();
			String teachercode=newgrade.getGrade_teacher();
			int value=newgrade.getGrade_value();
			if(value>0)
			{
				totalcredit=totalcredit+courseService.loadByCourseCode(coursecode).getCourse_credit();
				totalgrade=totalgrade+value*courseService.loadByCourseCode(coursecode).getCourse_credit();
			}
			//找到相应的实体类
			Teacher teacher=teacherService.loadByTeacherCode(teachercode);
			Course course=courseService.loadByCourseCode(coursecode);
			//提出相应的参数
			String courseName=course.getCourse_name();
			String courseTeacher=teacher.getTeacher_true();
			String courseCategory=course.getCourse_category();
		    int courseCredit=course.getCourse_credit();
		    
			//put的参数之所以要用courseName是为了区分不同的hash
			studentGrade.put(courseName, new StudentGrade(coursecode,courseName,courseTeacher,courseCredit,courseCategory,value));
		}
		List<StudentGrade> averagelist=new ArrayList();
		float averagegrade=totalgrade/totalcredit;
		
		StudentGrade foraverage=new StudentGrade(averagegrade);
		averagelist.add(foraverage);
		model.addAttribute("averagegrade",averagelist);
		model.addAttribute("test", studentGrade);
	
		
		return "student/showgrade";
	}
	//已选课程
	@RequestMapping(value="/selectedcourse")
	public String selectedcourse(Model model,HttpSession session)
	{
		String student_code=(String)session.getAttribute("loginstudent");
		
		List<Select1> selectList=selectService.showbystudent(student_code);
		
		List<StudentGrade> selectedcourselist=new ArrayList();
		for(int i=0;i<selectList.size();i++)
		{
			Select1 s=selectList.get(i);
			String coursecode=s.getSelect_course();//获取课程编号
			Course course1=courseService.loadByCourseCode(coursecode);
			String coursename=course1.getCourse_name();
			String coursecategory=course1.getCourse_category();
			String coursetime=course1.getCourse_time();
			String courseaddress=course1.getCourse_address();
			int coursecredit=course1.getCourse_credit();
			//获取教师
			Teacher teacher=teacherService.loadByTeacherCode(course1.getCourse_teacher());
			String courseteacher=teacher.getTeacher_true();
			//生成已选课程
			StudentGrade selectedCourse=new StudentGrade(coursecode,coursename,courseteacher,coursecredit,coursecategory,coursetime,courseaddress);
			selectedcourselist.add(selectedCourse);
		}
		//注意这里和上面的区别，这里是List
		model.addAttribute("test",selectedcourselist);
		return "student/selectedcourse";
		
	}
	//选课
	@RequestMapping(value="/choicecourse")
	public String choicecourse(Model model,HttpSession session)
	{
		//所有课程课程号数组
		
		List<Course> courseList=courseService.findAll();
		String [] allcoursecode= new String [courseList.size()];
		
		for(int i=0;i<courseList.size();i++)
		{
			Course course=courseList.get(i);
			String courseCode=course.getCourse_code();
			allcoursecode[i]=courseCode;
		}
		//已选课程的课程号数组
		String student_code=(String)session.getAttribute("loginstudent");
		List<Select1> selectList=selectService.showbystudent(student_code);
		String [] selectedcoursecode= new String [selectList.size()];
		for(int j=0;j<selectList.size();j++)
		{
			Select1 select1=selectList.get(j);
			String courseCode1=select1.getSelect_course();
			selectedcoursecode[j]=courseCode1;
			
		}
		//已选课程的StudentGrade数组
		List<StudentGrade> selectedcourselist=new ArrayList();
		for(int i=0;i<selectList.size();i++)
		{
			Select1 s=selectList.get(i);
			String coursecode=s.getSelect_course();//获取课程编号
			Course course1=courseService.loadByCourseCode(coursecode);
			String coursename=course1.getCourse_name();
			String coursecategory=course1.getCourse_category();
			int coursecredit=course1.getCourse_credit();
			//获取教师
			Teacher teacher=teacherService.loadByTeacherCode(course1.getCourse_teacher());
			String courseteacher=teacher.getTeacher_true();
			//生成已选课程
			StudentGrade selectedCourse=new StudentGrade(coursecode,coursename,courseteacher,coursecredit,coursecategory);
			selectedcourselist.add(selectedCourse);
		}
		//两者相减，得到未选择的课程号
		String [] coursecode= new String [courseList.size()-selectList.size()];
		int k=0;
		int j=0;
		for(int i=0;i<courseList.size();i++)
		{
			String allcode=allcoursecode[i];
			for(j=0;j<selectList.size();j++)
			{
				String selectedcode=selectedcoursecode[j];
				if(allcode.equals(selectedcode))
				{
					break;
				}
			}
			if(j==selectList.size())
			{
				coursecode[k]=allcode;
				k++;
			}
		}
		
		//提取课程信息
		List<StudentGrade> unselectedcourselist=new ArrayList();
		for(int i=0;i<coursecode.length;i++)
		{
			String code=coursecode[i];
			Course course=courseService.loadByCourseCode(code);
			String teachercode=course.getCourse_teacher();
			Teacher teacher=teacherService.loadByTeacherCode(teachercode);
			String teachername=teacher.getTeacher_true();
			String coursename=course.getCourse_name();
			String coursecategory=course.getCourse_category();
			int coursecredit=course.getCourse_credit();
			StudentGrade unselected=new StudentGrade(code,coursename,teachername,coursecredit,coursecategory);
			unselectedcourselist.add(unselected);
			System.out.println("jjjjjjjj"+unselected.getCourseName());
		}
		Map<String,Course> map = new HashMap<String,Course>();
		map.put("test", new Course(0,"","test","test","test",0));
		model.addAttribute("a",map);
		
		
		model.addAttribute("test",unselectedcourselist);
		model.addAttribute("test1",selectedcourselist);
		return "student/choicecourse";
	}
	//决定课程
	@RequestMapping(value="/{courseCode}/choice")
	public String decidecourse(@PathVariable String courseCode,Model model,HttpSession session)
	{
		//获取课程号和学生号，然后对select和grade表进行添加操作
		String student_code_temp=(String)session.getAttribute("loginstudent");
		Select1 select1_temp=new Select1(student_code_temp,courseCode);
		Course course_temp=courseService.loadByCourseCode(courseCode);
		//查找时间，确定课程时间是否冲突
		String courseTime=course_temp.getCourse_time();
		List<Select1> select_List=selectService.showbystudent(student_code_temp);
		String [] timelist=new String[select_List.size()];
		int m=0;
		for(m=0;m<select_List.size();m++)
		{
			String course_Code=select_List.get(m).getSelect_course();
			timelist[m]=courseService.loadByCourseCode(course_Code).getCourse_time();
			if(courseTime.equals(timelist[m]))
			{
				break;
			}
			
		}
		if(m!=select_List.size())
		{
			//不加入课程表
		}
		else
		{
			//添加入选课表
			selectService.save(select1_temp);
		}
		
		//查找该门课老师的code
		
		String courseName=course_temp.getCourse_name();
		String teachercode_temp=course_temp.getCourse_teacher();
	
		if(m!=select_List.size())
		{
			//不加入成绩表
		}
		else
		{
			//添加入成绩表
			Grade grade1=new Grade(courseCode,teachercode_temp,student_code_temp,0);
			gradeService.save(grade1);
		}
		
		
		
		//为了返回选课界面这里需要把上面choicecourse的所有内容都加上
		//所有课程课程号数组
		
				List<Course> courseList=courseService.findAll();
				String [] allcoursecode= new String [courseList.size()];
				
				for(int i=0;i<courseList.size();i++)
				{
					Course course=courseList.get(i);
					String courseCode_test=course.getCourse_code();
					allcoursecode[i]=courseCode_test;
				}
				//已选课程的课程号数组
				String student_code=(String)session.getAttribute("loginstudent");
				List<Select1> selectList=selectService.showbystudent(student_code);
				String [] selectedcoursecode= new String [selectList.size()];
				for(int j=0;j<selectList.size();j++)
				{
					Select1 select1=selectList.get(j);
					String courseCode1=select1.getSelect_course();
					selectedcoursecode[j]=courseCode1;
					
				}
				//已选课程的StudentGrade数组
				List<StudentGrade> selectedcourselist=new ArrayList();
				for(int i=0;i<selectList.size();i++)
				{
					Select1 s=selectList.get(i);
					String coursecode=s.getSelect_course();//获取课程编号
					Course course1=courseService.loadByCourseCode(coursecode);
					String coursename=course1.getCourse_name();
					String coursecategory=course1.getCourse_category();
					int coursecredit=course1.getCourse_credit();
					//获取教师
					Teacher teacher=teacherService.loadByTeacherCode(course1.getCourse_teacher());
					String courseteacher=teacher.getTeacher_true();
					//生成已选课程
					StudentGrade selectedCourse=new StudentGrade(coursecode,coursename,courseteacher,coursecredit,coursecategory);
					selectedcourselist.add(selectedCourse);
				}
				//两者相减，得到未选择的课程号
				String [] coursecode= new String [courseList.size()-selectList.size()];
				int k=0;
				int j=0;
				for(int i=0;i<courseList.size();i++)
				{
					String allcode=allcoursecode[i];
					for(j=0;j<selectList.size();j++)
					{
						String selectedcode=selectedcoursecode[j];
						if(allcode.equals(selectedcode))
						{
							break;
						}
					}
					if(j==selectList.size())
					{
						coursecode[k]=allcode;
						k++;
					}
				}
				
				//提取课程信息
				List<StudentGrade> unselectedcourselist=new ArrayList();
				for(int i=0;i<coursecode.length;i++)
				{
					String code=coursecode[i];
					Course course=courseService.loadByCourseCode(code);
					String teachercode=course.getCourse_teacher();
					Teacher teacher=teacherService.loadByTeacherCode(teachercode);
					String teachername=teacher.getTeacher_true();
					String coursename=course.getCourse_name();
					String coursecategory=course.getCourse_category();
					int coursecredit=course.getCourse_credit();
					StudentGrade unselected=new StudentGrade(code,coursename,teachername,coursecredit,coursecategory);
					unselectedcourselist.add(unselected);
					
				}
				Map<String,Course> map = new HashMap<String,Course>();
				if(m==select_List.size())
				{
					map.put(courseName, new Course(0,"选择"+courseName+"课程成功!","test","test","test",0));
				}
				else
				{
					map.put(courseName, new Course(0,"选课失败，课程时间冲突!","test","test","test",0));
				}
				
				
				model.addAttribute("a",map);
				
				model.addAttribute("test",unselectedcourselist);
				model.addAttribute("test1",selectedcourselist);
			
			
		return "student/choicecourse";
	}
	//删除课程
	@RequestMapping(value="/deletecourse")
	public String deletecourse(Model model,HttpSession session)
	{
		//首先展示出已选课程，代码同上面的已选课程
        String student_code=(String)session.getAttribute("loginstudent");
		
		List<Select1> selectList=selectService.showbystudent(student_code);
		
		List<StudentGrade> selectedcourselist=new ArrayList();
		for(int i=0;i<selectList.size();i++)
		{
			Select1 s=selectList.get(i);
			String coursecode=s.getSelect_course();//获取课程编号
			Course course1=courseService.loadByCourseCode(coursecode);
			String coursename=course1.getCourse_name();
			String coursecategory=course1.getCourse_category();
			int coursecredit=course1.getCourse_credit();
			//获取教师
			Teacher teacher=teacherService.loadByTeacherCode(course1.getCourse_teacher());
			String courseteacher=teacher.getTeacher_true();
			//生成已选课程
			StudentGrade selectedCourse=new StudentGrade(coursecode,coursename,courseteacher,coursecredit,coursecategory);
			selectedcourselist.add(selectedCourse);
		}
		Map<String,Course> map = new HashMap<String,Course>();
		map.put("test", new Course(0,"","test","test","test",0));
		model.addAttribute("b",map);
		//注意这里和上面的区别，这里是List
		model.addAttribute("test",selectedcourselist);
		return "student/deletecourse";
	
		
	}
	//决定删除哪一门课程
	@RequestMapping(value="/{courseCode}/delete")
	public String decidedeletecourse(@PathVariable String courseCode,Model model,HttpSession session)
	{
		//通过课程号找到Grade对象
		String studentCode=(String)session.getAttribute("loginstudent");
		List<Grade> deleteGradeList=gradeService.showViaStudentPlusCourse(studentCode, courseCode);
		Grade deleteGrade=deleteGradeList.get(0);
		gradeService.delete(deleteGrade);
		List<Select1> deleteSelect1List=selectService.ShowViaCoursePlusStudent(studentCode, courseCode);
		Select1 deleteSelect1=deleteSelect1List.get(0);
		selectService.delete(deleteSelect1);
		//复制上面的代码
		//首先展示出已选课程，代码同上面的已选课程
        String student_code=(String)session.getAttribute("loginstudent");
		
		List<Select1> selectList=selectService.showbystudent(student_code);
		
		List<StudentGrade> selectedcourselist=new ArrayList();
		for(int i=0;i<selectList.size();i++)
		{
			Select1 s=selectList.get(i);
			String coursecode=s.getSelect_course();//获取课程编号
			Course course1=courseService.loadByCourseCode(coursecode);
			String coursename=course1.getCourse_name();
			String coursecategory=course1.getCourse_category();
			int coursecredit=course1.getCourse_credit();
			//获取教师
			Teacher teacher=teacherService.loadByTeacherCode(course1.getCourse_teacher());
			String courseteacher=teacher.getTeacher_true();
			//生成已选课程
			StudentGrade selectedCourse=new StudentGrade(coursecode,coursename,courseteacher,coursecredit,coursecategory);
			selectedcourselist.add(selectedCourse);
		}
		//查找删除的课程的名称
		String course_Code=deleteGrade.getGrade_course();
		String course_Name=courseService.loadByCourseCode(course_Code).getCourse_name();
		
		Map<String,Course> map = new HashMap<String,Course>();
		map.put(course_Name, new Course(0,"删除"+course_Name+"课程成功!","test","test","test",0));
		
		model.addAttribute("b",map);
		//注意这里和上面的区别，这里是List
		model.addAttribute("test",selectedcourselist);
		return "student/deletecourse";
		
	}
	 
	@RequestMapping(value="forgetpassword")
	public String forgetpassword()
	{
		
	   return "student/forgetpassword";
	}
	//忘记密码的处理，需要发送一封邮件
	@RequestMapping(value="retrievepassword")
	public String retrievepassword(Model model,String student_email,String student_idcard,String student_name)
	{
		
		Student student=studentService.loadByStudentName(student_name);
		String true_email=student.getStudent_email();
		String true_idcard=student.getStudent_idcard();
		
		//验证通过
		if(student_email.equals(true_email)&&student_idcard.equals(true_idcard))
		{
			String student_passwrod=student.getStudent_password();
			//发送邮件
			Mail mail = new Mail();
	        mail.setTo(true_email);
	        mail.setFrom("brucexiajun@126.com");// 你的邮箱
	        mail.setHost("smtp.126.com"); //smtp.qq.com
	        mail.setUsername("brucexiajun");// 用户
	        mail.setPassword("xj871029513627");// 密码
	        mail.setSubject("找回您的密码");
	        mail.setContent("用户"+student_name+"的密码是"+student_passwrod);
	        if (mail.sendMail()) {
	            System.out.println(" 发送成功");
	        }
	        
	        System.out.println("邮箱是："+true_email);
	        List<Student> studentList=new ArrayList();
	        studentList.add(student);
	        model.addAttribute("password",studentList);
	        return "student/informretrieve";
		}
		//验证未通过，返回验证页面
		else
		{
			return "student/forgetpassword";
		}
	}
	//返回登陆界面
	@RequestMapping(value="returnlogin")
	public String returnlogin()
	{
		return "redirect:/login";
	}
	//下载成绩单
	@RequestMapping(value="downloadsheet")
	public String downloadsheet(HttpSession session)
	{
		String studentCode=(String)session.getAttribute("loginstudent");
		//获取成绩信息
		 List<Grade> gradeList= gradeService.ShowGrade(studentCode);
		 List<StudentGrade> studentGradeList=new ArrayList();
		 for(int i=0;i<gradeList.size();i++)
		 {
			 Grade grade=gradeList.get(i);
			 String course_code=grade.getGrade_course();
			 String teacher_code=grade.getGrade_teacher();
			 String course_name=courseService.loadByCourseCode(course_code).getCourse_name();
			 int course_credit=courseService.loadByCourseCode(course_code).getCourse_credit();
			 String teacher_name=teacherService.loadByTeacherCode(teacher_code).getTeacher_true();
			 String course_category=courseService.loadByCourseCode(course_code).getCourse_category();
			 int grade_value=grade.getGrade_value();
			 StudentGrade studentGrade=new StudentGrade(course_code,course_name,teacher_name,course_credit,course_category,grade_value);
			 studentGradeList.add(studentGrade);
		 }
		try {
            WritableWorkbook wwb = null;
            File f=new File("C:/Software/IDE/MyEclipse/MyWorkSpace/CourseSelectionSystem/WebRoot/resources/download");
            if(!f.exists()){
              f.mkdirs();
             }
            
               // 创建可写入的Excel工作簿
              
              // File file=new File(fileName);
               File file=new File("C:/Software/IDE/MyEclipse/MyWorkSpace/CourseSelectionSystem/WebRoot/resources/download/MyGrade.xls");
               
               if (!file.exists()) {
                   file.createNewFile();
               }
               //以fileName为文件名来创建一个Workbook
               wwb = Workbook.createWorkbook(file);

               // 创建工作表
               WritableSheet ws = wwb.createSheet("Test Shee 1", 0);
               
               //查询数据库中所有的数据
               
               //要插入到的Excel表格的行号，默认从0开始
               Label labelId= new Label(0, 0, "课程号");//表示第
               Label labelName= new Label(1, 0, "课程名");
               Label labelSex= new Label(2, 0, "任课教师");
               Label labelNum= new Label(3, 0, "课程属性");
               Label labelNum1= new Label(4, 0, "学分");
               Label labelNum2= new Label(5, 0, "成绩");
               
               ws.addCell(labelId);
               ws.addCell(labelName);
               ws.addCell(labelSex);
               ws.addCell(labelNum);
               ws.addCell(labelNum1);
               ws.addCell(labelNum2);
               for (int i = 0; i < studentGradeList.size(); i++) {
                   
                   Label labelId_i= new Label(0, i+1, studentGradeList.get(i).getCourseCode()+"");
                   Label labelName_i= new Label(1, i+1, studentGradeList.get(i).getCourseName());
                   Label labelSex_i= new Label(2, i+1, studentGradeList.get(i).getCourseTeacher());
                   Label labelNum_i= new Label(3, i+1, studentGradeList.get(i).getCourseCategory()+"");
                   Label labelNum_i1= new Label(4, i+1, studentGradeList.get(i).getCourseCredit()+"");
                   Label labelNum_i2= new Label(5, i+1, studentGradeList.get(i).getCourseValue()+"");
                   ws.addCell(labelId_i);
                   ws.addCell(labelName_i);
                   ws.addCell(labelSex_i);
                   ws.addCell(labelNum_i);
                   ws.addCell(labelNum_i1);
                   ws.addCell(labelNum_i2);
               }
             
              //写进文档
               wwb.write();
              // 关闭Excel工作簿对象
               wwb.close();
             
        } catch (Exception e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        } 
		return "student/SheetDownloadSuccess";
	}
	//修改密码
	@RequestMapping(value="changepassword")
	public String changepassword()
	{
		return "student/ChangePassword";
	}
	//提交新密码
	@RequestMapping(value="submitpassword")
	public String submitpassword(HttpSession session,String student_password,String new_password,String ensure_password,String student_idcard)
	{
		String studentCode=(String)session.getAttribute("loginstudent");
		Student s=studentService.loadByStudentCode(studentCode);
		String true_password=s.getStudent_password();
		String true_idcard=s.getStudent_idcard();
		if(true_password.equals(student_password)&&true_idcard.equals(student_idcard))
		{
			if(new_password.equals(ensure_password))
			{
				//改密码
				studentService.updatepassword(studentCode, new_password);
				return "student/ChangePassSucc";
				
			}
			//两次输入的密码不一致
			else
			{
				return "student/ChangePassword";
			}
			
			
		}
		//验证不通过
		else
		{
			return "student/ChangePassword";
		}
	}
	//注册，这里只能验证注册的内容，并不能把错误信息传给视图层
	@RequestMapping(value="register",method=RequestMethod.POST)
	public String register(@Validated Student student,BindingResult br,String student_name,String student_password,String student_code,String student_true,String student_email,String student_idcard,String ensure_password)
		{
		   if(student_password.equals(ensure_password)&&!(br.hasErrors()))
		    {
			Student s=new Student(student_name,student_password,student_code,student_email,student_idcard,student_true);
			studentService.save(s);
			return "redirect:/register_success";
		     }
		   else
		   {
				return "redirect:/register";
		   }
		}	
	//课程查询
	@RequestMapping(value="searchcourse")
	public String searchcourse()
	{
		return "student/searchcourse";
	}
	//按上课时间查询
	@RequestMapping(value="searchviatime")
	public String searchviatime(String course_time,Model model)
	{
		List<StudentGrade> timecourselist=new ArrayList();
		List<Course> courseviatime=courseService.searchviatime(course_time);
		for(int n=0;n<courseviatime.size();n++)
		{
			String time=courseviatime.get(n).getCourse_time();
			String address=courseviatime.get(n).getCourse_address();
			String category=courseviatime.get(n).getCourse_category();
			String code=courseviatime.get(n).getCourse_code();
			String name=courseviatime.get(n).getCourse_name();
			int credit=courseviatime.get(n).getCourse_credit();
			String teachername=teacherService.loadByTeacherCode(courseviatime.get(n).getCourse_teacher()).getTeacher_true();
			StudentGrade sg=new StudentGrade(code,name,teachername,credit,category,time,address);
			timecourselist.add(sg);
			
		}
		model.addAttribute("test",timecourselist);
		return "student/searchresult";
	}
	//按课程类别查询
	@RequestMapping(value="searchviacategory")
	public String searchviacategory(String course_category,Model model)
	{
		List<StudentGrade> timecourselist=new ArrayList();
		List<Course> courseviatime=courseService.searchviacategory(course_category);
		for(int n=0;n<courseviatime.size();n++)
		{
			String time=courseviatime.get(n).getCourse_time();
			String address=courseviatime.get(n).getCourse_address();
			String category=courseviatime.get(n).getCourse_category();
			String code=courseviatime.get(n).getCourse_code();
			String name=courseviatime.get(n).getCourse_name();
			int credit=courseviatime.get(n).getCourse_credit();
			String teachername=teacherService.loadByTeacherCode(courseviatime.get(n).getCourse_teacher()).getTeacher_true();
			StudentGrade sg=new StudentGrade(code,name,teachername,credit,category,time,address);
			timecourselist.add(sg);
			
		}
		model.addAttribute("test",timecourselist);
		return "student/searchresult";
	}
	//下载成绩单第二版，通过浏览器下载
	@RequestMapping(value="download")
	public void download(HttpServletResponse response)throws FileNotFoundException
	{
		  // 下载本地文件
        String fileName = "MyGrade.xls".toString(); // 文件的默认保存名
        // 读到流中
        InputStream inStream = new FileInputStream("C:/Software/IDE/MyEclipse/MyWorkSpace/CourseSelectionSystem/WebRoot/resources/download/MyGrade.xls");// 文件的存放路径
        //InputStream inStream = new FileInputStream("G:/电影/阿甘正传/阿甘正传.rmvb");// 文件的存放路径
        // 设置输出的格式
        response.reset();
        response.setContentType("bin");
        response.addHeader("Content-Disposition", "attachment; filename=\"" + fileName + "\"");
        // 循环取出流中的数据
        byte[] b = new byte[100];
        int len;
        try {
            while ((len = inStream.read(b)) > 0)
                response.getOutputStream().write(b, 0, len);
            inStream.close();
        } catch (IOException e) {
            e.printStackTrace();
        }
	}
	
}
