package course.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="teacher")
public class Teacher {
private int id;
private String teacher_name;
private String teacher_code;
private String teacher_password;
private String teacher_true;
private String teacher_course;
public Teacher(int id, String teacher_name, String teacher_code,
		String teacher_password, String teacher_true, String teacher_course) {
	super();
	this.id = id;
	this.teacher_name = teacher_name;
	this.teacher_code = teacher_code;
	this.teacher_password = teacher_password;
	this.teacher_true = teacher_true;
	this.teacher_course = teacher_course;
}
public Teacher() {
	super();
}
@GeneratedValue
@Id
@Column(name="id")
public int getId() {
	return id;
}
public void setId(int id) {
	this.id = id;
}
@Column(name="teacher_name")
public String getTeacher_name() {
	return teacher_name;
}
public void setTeacher_name(String teacher_name) {
	this.teacher_name = teacher_name;
}
@Column(name="teacher_code")
public String getTeacher_code() {
	return teacher_code;
}
public void setTeacher_code(String teacher_code) {
	this.teacher_code = teacher_code;
}
@Column(name="teacher_password")
public String getTeacher_password() {
	return teacher_password;
}
public void setTeacher_password(String teacher_password) {
	this.teacher_password = teacher_password;
}
@Column(name="teacher_true")
public String getTeacher_true() {
	return teacher_true;
}
public void setTeacher_true(String teacher_true) {
	this.teacher_true = teacher_true;
}
@Column(name="teacher_course")
public String getTeacher_course() {
	return teacher_course;
}
public void setTeacher_course(String teacher_course) {
	this.teacher_course = teacher_course;
}
}
