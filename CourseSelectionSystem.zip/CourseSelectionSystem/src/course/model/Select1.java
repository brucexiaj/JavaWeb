package course.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="select1")
public class Select1 {
	private int id;
	private String select_student;
	private String select_course;
	@GeneratedValue
	@Id
	@Column(name="id")
	public int getId() {
		return id;
	}
	
	public void setId(int id) {
		this.id = id;
	}
	
	
	@Column(name="select_student")
	public String getSelect_student() {
		return select_student;
	}
	public void setSelect_student(String select_student) {
		this.select_student = select_student;
	}
	
	
	@Column(name="select_course")
	public String getSelect_course() {
		return select_course;
	}
	public void setSelect_course(String select_course) {
		this.select_course = select_course;
	}
	
	public Select1() {
		super();
	}
	public Select1(int id, String select_student, String select_course) {
		super();
		this.id = id;
		this.select_student = select_student;
		this.select_course = select_course;
	}

	public Select1(String select_student, String select_course) {
		super();
		this.select_student = select_student;
		this.select_course = select_course;
	}
	
	
}
