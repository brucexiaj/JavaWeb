package course.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="course")
public class Course {
	private int id;
	
	
	@Column(name="course_name")
	public String getCourse_name() {
		return course_name;
	}
	public void setCourse_name(String course_name) {
		this.course_name = course_name;
	}
	@Column(name="course_teacher")
	public String getCourse_teacher() {
		return course_teacher;
	}
	public void setCourse_teacher(String course_teacher) {
		this.course_teacher = course_teacher;
	}
	@Column(name="course_code")
	public String getCourse_code() {
		return course_code;
	}
	public void setCourse_code(String course_code) {
		this.course_code = course_code;
	}
	
	
	

	private String course_name;
	private String course_code;
	private String course_category;
	private String course_teacher;
	private int course_credit;
	private String course_time;
	private String course_address;
	
	
	@Column(name="course_address")
	public String getCourse_address() {
		return course_address;
	}
	@Column(name="course_time")
	public String getCourse_time() {
		return course_time;
	}
	//除了id
	public Course(String course_name, String course_code,
			String course_category, String course_teacher, int course_credit,
			String course_time, String course_address) {
		super();
		this.course_name = course_name;
		this.course_code = course_code;
		this.course_category = course_category;
		this.course_teacher = course_teacher;
		this.course_credit = course_credit;
		this.course_time = course_time;
		this.course_address = course_address;
	}
	public void setCourse_time(String course_time) {
		this.course_time = course_time;
	}
	public void setCourse_address(String course_address) {
		this.course_address = course_address;
	}
	@GeneratedValue
	@Id
	@Column(name="id")
	public int getId() {
		return id;
	}
	@Column(name="course_category")
	public String getCourse_category() {
		return course_category;
	}
	public void setCourse_category(String course_category) {
		this.course_category = course_category;
	}
	public Course(int id, String course_name, String course_code,
			String course_category, String course_teacher, int course_credit) {
		super();
		this.id = id;
		this.course_name = course_name;
		this.course_code = course_code;
		this.course_category = course_category;
		this.course_teacher = course_teacher;
		this.course_credit = course_credit;
	}
	
	@Column(name="course_credit")
	public int getCourse_credit() {
		return course_credit;
	}
	public void setCourse_credit(int course_credit) {
		this.course_credit = course_credit;
	}
	public Course() {
		super();
	}
	public void setId(int id) {
		this.id = id;
	}
	
}
