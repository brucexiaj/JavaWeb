package course.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Transient;





import org.hibernate.validator.constraints.NotEmpty;

import course.constraints.CaseMode;
import course.constraints.CheckCase;

@Entity
@Table(name="student")
public class Student {
	private int id;
	@GeneratedValue
	@Id
	@Column(name="id")
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	//这里采用的是自定义验证，详细请见官方文档：http://docs.jboss.org/hibernate/validator/4.3/reference/en-US/pdf/hibernate_validator_reference.pdf
	private String student_name;
	@Column(name="student_name")
	@CheckCase(CaseMode.LOWER)
	public String getStudent_name() {
		return student_name;
	}
	public void setStudent_name(String student_name) {
		this.student_name = student_name;
	}
	@Column(name="student_password")
	@NotEmpty(message="密码不能为空!")
	public String getStudent_password() {
		return student_password;
	}
	public void setStudent_password(String student_password) {
		this.student_password = student_password;
	}
	@Column(name="student_code")
	public String getStudent_code() {
		return student_code;
	}
	public void setStudent_code(String student_code) {
		this.student_code = student_code;
	}
	
	
	//不包含身份证，邮箱，验证码的构造函数
	public Student(int id, String student_name, String student_password,
			String student_code,String student_true) {
		super();
		this.id = id;
		this.student_name = student_name;
		this.student_password = student_password;
		this.student_code = student_code;
		this.student_true=student_true;
	}
	public Student()
	{
		
	}
	private String student_password;
	private String student_code;
	public String student_email;
	public String student_idcard;
	public String student_ipaddress;
	public String student_device;
	//检测使用者的设备，@Transient表示这个不需要注入数据库
	@Transient
	public String getStudent_device() {
		return student_device;
	}
	public void setStudent_device(String student_device) {
		this.student_device = student_device;
	}
	@Transient
	public String getStudent_ipaddress() {
		return student_ipaddress;
	}
	//构造函数name&code&ipaddress
	public Student(String student_name, String student_code,
			String student_ipaddress) {
		super();
		this.student_name = student_name;
		this.student_code = student_code;
		this.student_ipaddress = student_ipaddress;
		
	}
	//构造函数device
	public Student(String student_device) {
		super();
		this.student_device = student_device;
	}
	public void setStudent_ipaddress(String student_ipaddress) {
		this.student_ipaddress = student_ipaddress;
	}
	@Column(name="student_email")
	public String getStudent_email() {
		return student_email;
	}
	public void setStudent_email(String student_email) {
		this.student_email = student_email;
	}
	@Column(name="student_idcard")
	public String getStudent_idcard() {
		return student_idcard;
	}
	//除了验证码,id之外的所有的变量
	public Student(String student_name, String student_password,
			String student_code, String student_email, String student_idcard,
			String student_true) {
		super();
		
		this.student_name = student_name;
		this.student_password = student_password;
		this.student_code = student_code;
		this.student_email = student_email;
		this.student_idcard = student_idcard;
		this.student_true = student_true;
	}
	public void setStudent_idcard(String student_idcard) {
		this.student_idcard = student_idcard;
	}
	@Column(name="student_true")
	public String getStudent_true() {
		return student_true;
	}
	public void setStudent_true(String student_true) {
		this.student_true = student_true;
	}
	private String student_true;
	 private String code;
	    @Transient   //不需要持久到DB的属性使用该注解
	    public String getCode() {
	        return code;
	    }
	    
	    public void setCode(String code) {
	        this.code = code;
	    }
}
