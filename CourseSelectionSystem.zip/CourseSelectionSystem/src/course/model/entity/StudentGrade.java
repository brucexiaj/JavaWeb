package course.model.entity;

public class StudentGrade {
private String courseCode;
private String courseName;
private String courseTeacher;
private int courseCredit;
private String courseCategory;
private int courseValue;
private String courseTime;
private String courseAddress;
private float averageGrade;
public StudentGrade(float averageGrade) {
	super();
	this.averageGrade = averageGrade;
}
public float getAverageGrade() {
	return averageGrade;
}
public void setAverageGrade(float averageGrade) {
	this.averageGrade = averageGrade;
}
public String getCourseTime() {
	return courseTime;
}
public StudentGrade(String courseCode, String courseName, String courseTeacher,
		int courseCredit, String courseCategory, 
		String courseTime, String courseAddress) {
	super();
	this.courseCode = courseCode;
	this.courseName = courseName;
	this.courseTeacher = courseTeacher;
	this.courseCredit = courseCredit;
	this.courseCategory = courseCategory;
	
	this.courseTime = courseTime;
	this.courseAddress = courseAddress;
}
public void setCourseTime(String courseTime) {
	this.courseTime = courseTime;
}
public String getCourseAddress() {
	return courseAddress;
}
public void setCourseAddress(String courseAddress) {
	this.courseAddress = courseAddress;
}
public StudentGrade(String courseCode, String courseName, String courseTeacher,
		int courseCredit, String courseCategory, int courseValue) {
	super();
	this.courseCode = courseCode;
	this.courseName = courseName;
	this.courseTeacher = courseTeacher;
	this.courseCredit = courseCredit;
	this.courseCategory = courseCategory;
	this.courseValue = courseValue;
}
public String getCourseCode() {
	return courseCode;
}
public void setCourseCode(String courseCode) {
	this.courseCode = courseCode;
}
public String getCourseName() {
	return courseName;
}
public void setCourseName(String courseName) {
	this.courseName = courseName;
}
public String getCourseTeacher() {
	return courseTeacher;
}
public void setCourseTeacher(String courseTeacher) {
	this.courseTeacher = courseTeacher;
}
public int getCourseCredit() {
	return courseCredit;
}
public void setCourseCredit(int courseCredit) {
	this.courseCredit = courseCredit;
}
public String getCourseCategory() {
	return courseCategory;
}
public void setCourseCategory(String courseCategory) {
	this.courseCategory = courseCategory;
}
public int getCourseValue() {
	return courseValue;
}
public StudentGrade(String courseCode, String courseName, String courseTeacher,
		int courseCredit, String courseCategory) {
	super();
	this.courseCode = courseCode;
	this.courseName = courseName;
	this.courseTeacher = courseTeacher;
	this.courseCredit = courseCredit;
	this.courseCategory = courseCategory;
}
public void setCourseValue(int courseValue) {
	this.courseValue = courseValue;
}
}
