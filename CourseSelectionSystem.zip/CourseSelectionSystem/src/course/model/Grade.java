package course.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="grade")
public class Grade {
	private int id;
	private String grade_course;
	private String grade_teacher;
	private String grade_student;
	private int grade_value;
	
	@GeneratedValue
	@Id
	@Column(name="id")
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public Grade(String grade_course, String grade_teacher,
			String grade_student, int grade_value) {
		super();
		this.grade_course = grade_course;
		this.grade_teacher = grade_teacher;
		this.grade_student = grade_student;
		this.grade_value = grade_value;
	}
	@Column(name="grade_course")
	public String getGrade_course() {
		return grade_course;
	}
	public void setGrade_course(String grade_course) {
		this.grade_course = grade_course;
	}
	@Column(name="grade_teacher")
	public String getGrade_teacher() {
		return grade_teacher;
	}
	public void setGrade_teacher(String grade_teacher) {
		this.grade_teacher = grade_teacher;
	}
	@Column(name="grade_student")
	public String getGrade_student() {
		return grade_student;
	}
	public void setGrade_student(String grade_student) {
		this.grade_student = grade_student;
	}
	@Column(name="grade_value")
	public int getGrade_value() {
		return grade_value;
	}
	public void setGrade_value(int grade_value) {
		this.grade_value = grade_value;
	}
	
	
	public Grade() {
		super();
	}
	public Grade(int id, String grade_course, String grade_teacher,
			String grade_student, int grade_value) {
		super();
		this.id = id;
		this.grade_course = grade_course;
		this.grade_teacher = grade_teacher;
		this.grade_student = grade_student;
		this.grade_value = grade_value;
	}
	
	
	
}
