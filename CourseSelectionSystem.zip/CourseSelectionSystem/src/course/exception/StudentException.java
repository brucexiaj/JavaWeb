package course.exception;

public class StudentException extends RuntimeException {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public StudentException() {
		super();
		// TODO Auto-generated constructor stub
	}

	public StudentException(String message, Throwable cause) {
		super(message, cause);
		// TODO Auto-generated constructor stub
	}

	public StudentException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}

	public StudentException(Throwable cause) {
		super(cause);
		// TODO Auto-generated constructor stub
	}

	
}
