package course.constraints;

public enum CaseMode {
	UPPER,
	LOWER;
}
